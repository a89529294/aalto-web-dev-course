<svelte:head>
  <title>Contact</title>
</svelte:head>

<h1>Contact</h1>
<header>Contact</header>
<p>You can contact me here.</p>

<div class="mockup-code">
  <pre data-prefix="$"><code>npm i daisyui</code></pre>
</div>
