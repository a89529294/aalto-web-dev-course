<header class="navbar bg-base-100 drop-shadow">
  <div class="flex-1 text-xl">My application</div>
  <nav class="flex-none">
    <ul class="px-1 menu menu-horizontal">
      <li><a href="/">Home</a></li>
      <li><a href="/about">About</a></li>
      <li><a href="/contact">Contact</a></li>
    </ul>
  </nav>
</header>
