<div class="min-h-screen hero bg-base-200">
  <div class="text-center hero-content">
    <div class="max-w-md">
      <h1 class="text-5xl font-bold">Hello world!</h1>
      <p class="py-6">Scroll down and pick your journey.</p>
    </div>
  </div>
</div>
